const express = require('express');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const { load, save, nextId } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// شماره‌ای که به صورت پیش‌فرض ادمین سایت است
const ADMIN_PHONE = '09150026844';

const GENRES = [
  { key: 'crime', label: 'جنایی' },
  { key: 'horror', label: 'ترسناک' },
  { key: 'anime', label: 'انیمیشن' },
  { key: 'comedy', label: 'طنز' },
  { key: 'drama', label: 'درام' },
];

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/static', express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));

app.use(session({
  secret: 'change-this-secret-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 30 }
}));

// در دسترس بودن کاربر لاگین‌شده در همه‌ی ویوها
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.genres = GENRES;
  next();
});

// ---------- آپلود فایل ----------
const posterStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'public/uploads/posters')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_'))
});
const uploadPoster = multer({ storage: posterStorage });

const videoStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'public/uploads/videos')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_'))
});
const uploadVideo = multer({ storage: videoStorage });

// ---------- Middleware ----------
function requireAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || !req.session.user.isAdmin) return res.status(403).send('دسترسی ندارید');
  next();
}

// ---------- صفحه اصلی ----------
app.get('/', (req, res) => {
  const db = load();
  const genreFilter = req.query.genre;
  let seriesList = db.series;
  if (genreFilter) seriesList = seriesList.filter(s => s.genre === genreFilter);
  res.render('index', { seriesList, genreFilter });
});

// ---------- ثبت‌نام با شماره موبایل ----------
app.get('/register', (req, res) => {
  res.render('register', { step: 1, phone: '', error: null, message: null });
});

// مرحله ۱: کاربر شماره را می‌زند -> کد ساخته و روی صفحه نمایش داده می‌شود (چون سرویس پیامک متصل نیست)
app.post('/register/send-code', (req, res) => {
  const { phone } = req.body;
  const db = load();
  if (!/^09\d{9}$/.test(phone)) {
    return res.render('register', { step: 1, phone, error: 'شماره موبایل معتبر نیست', message: null });
  }
  if (db.users.find(u => u.phone === phone)) {
    return res.render('register', { step: 1, phone, error: 'این شماره قبلا ثبت‌نام کرده، وارد شوید', message: null });
  }
  const code = Math.floor(1000 + Math.random() * 9000).toString();
  db.otps[phone] = { code, expiresAt: Date.now() + 5 * 60 * 1000 };
  save(db);
  // چون اتصال به سامانه پیامک وجود ندارد، کد همینجا نمایش داده می‌شود
  res.render('register', { step: 2, phone, error: null, message: null, demoCode: code });
});

// مرحله ۲: تایید کد + ساخت حساب با نام دلخواه
app.post('/register/verify', (req, res) => {
  const { phone, code, name, password } = req.body;
  const db = load();
  const otp = db.otps[phone];
  if (!otp || otp.code !== code || Date.now() > otp.expiresAt) {
    return res.render('register', { step: 2, phone, error: 'کد وارد شده اشتباه یا منقضی است', message: null, demoCode: null });
  }
  if (!name || !password || password.length < 4) {
    return res.render('register', { step: 2, phone, error: 'نام و رمز عبور (حداقل ۴ کاراکتر) را کامل وارد کنید', message: null, demoCode: otp.code });
  }
  const id = nextId(db.users);
  const passwordHash = bcrypt.hashSync(password, 10);
  const isAdmin = phone === ADMIN_PHONE;
  const user = { id, name, phone, passwordHash, isAdmin };
  db.users.push(user);
  delete db.otps[phone];
  save(db);
  req.session.user = { id: user.id, name: user.name, phone: user.phone, isAdmin: user.isAdmin };
  res.redirect('/');
});

// ---------- ورود ----------
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});
app.post('/login', (req, res) => {
  const { phone, password } = req.body;
  const db = load();
  const user = db.users.find(u => u.phone === phone);
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.render('login', { error: 'شماره یا رمز عبور اشتباه است' });
  }
  req.session.user = { id: user.id, name: user.name, phone: user.phone, isAdmin: user.isAdmin };
  res.redirect('/');
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// ---------- ویرایش پروفایل ----------
app.get('/profile', requireAuth, (req, res) => {
  res.render('profile', { error: null, message: null });
});
app.post('/profile', requireAuth, (req, res) => {
  const { name, password } = req.body;
  const db = load();
  const user = db.users.find(u => u.id === req.session.user.id);
  if (name) user.name = name;
  if (password && password.length >= 4) user.passwordHash = bcrypt.hashSync(password, 10);
  save(db);
  req.session.user.name = user.name;
  res.render('profile', { error: null, message: 'تغییرات ذخیره شد' });
});

// ---------- صفحه سریال ----------
app.get('/series/:id', (req, res) => {
  const db = load();
  const s = db.series.find(x => x.id == req.params.id);
  if (!s) return res.status(404).send('یافت نشد');
  res.render('series', { s });
});

// ---------- پخش قسمت ----------
app.get('/watch/:seriesId/:episodeId', (req, res) => {
  const db = load();
  const s = db.series.find(x => x.id == req.params.seriesId);
  if (!s) return res.status(404).send('یافت نشد');
  let ep = null, season = null;
  for (const se of s.seasons) {
    const found = se.episodes.find(e => e.id == req.params.episodeId);
    if (found) { ep = found; season = se; break; }
  }
  if (!ep) return res.status(404).send('قسمت یافت نشد');
  res.render('watch', { s, season, ep });
});

// ================= پنل مدیریت =================
app.get('/admin', requireAdmin, (req, res) => {
  const db = load();
  res.render('admin', { seriesList: db.series });
});

app.post('/admin/series', requireAdmin, uploadPoster.single('poster'), (req, res) => {
  const { title, description, genre } = req.body;
  const db = load();
  const id = nextId(db.series);
  const poster = req.file ? '/uploads/posters/' + req.file.filename : '';
  db.series.push({ id, title, description, genre, poster, seasons: [] });
  save(db);
  res.redirect('/admin');
});

app.post('/admin/series/:id/delete', requireAdmin, (req, res) => {
  const db = load();
  db.series = db.series.filter(s => s.id != req.params.id);
  save(db);
  res.redirect('/admin');
});

app.get('/admin/series/:id', requireAdmin, (req, res) => {
  const db = load();
  const s = db.series.find(x => x.id == req.params.id);
  if (!s) return res.status(404).send('یافت نشد');
  res.render('admin-series', { s });
});

app.post('/admin/series/:id/season', requireAdmin, (req, res) => {
  const { number } = req.body;
  const db = load();
  const s = db.series.find(x => x.id == req.params.id);
  const sid = s.seasons.length ? Math.max(...s.seasons.map(x => x.id)) + 1 : 1;
  s.seasons.push({ id: sid, number: Number(number), episodes: [] });
  save(db);
  res.redirect('/admin/series/' + s.id);
});

app.post('/admin/series/:id/season/:seasonId/delete', requireAdmin, (req, res) => {
  const db = load();
  const s = db.series.find(x => x.id == req.params.id);
  s.seasons = s.seasons.filter(se => se.id != req.params.seasonId);
  save(db);
  res.redirect('/admin/series/' + s.id);
});

// آپلود قسمت با ۴ کیفیت جدا
app.post('/admin/series/:id/season/:seasonId/episode',
  requireAdmin,
  uploadVideo.fields([
    { name: 'q240', maxCount: 1 },
    { name: 'q480', maxCount: 1 },
    { name: 'q720', maxCount: 1 },
    { name: 'q1080', maxCount: 1 },
  ]),
  (req, res) => {
    const { title, number } = req.body;
    const db = load();
    const s = db.series.find(x => x.id == req.params.id);
    const season = s.seasons.find(x => x.id == req.params.seasonId);
    const eid = season.episodes.length ? Math.max(...season.episodes.map(x => x.id)) + 1 : 1;
    const qualities = {};
    for (const key of ['q240', 'q480', 'q720', 'q1080']) {
      if (req.files[key]) qualities[key] = '/uploads/videos/' + req.files[key][0].filename;
    }
    season.episodes.push({ id: eid, number: Number(number), title, qualities });
    save(db);
    res.redirect('/admin/series/' + s.id);
  }
);

app.post('/admin/series/:id/season/:seasonId/episode/:episodeId/delete', requireAdmin, (req, res) => {
  const db = load();
  const s = db.series.find(x => x.id == req.params.id);
  const season = s.seasons.find(x => x.id == req.params.seasonId);
  season.episodes = season.episodes.filter(e => e.id != req.params.episodeId);
  save(db);
  res.redirect('/admin/series/' + s.id);
});

app.listen(PORT, () => {
  console.log(`سرور روی http://localhost:${PORT} اجرا شد`);
  console.log(`شماره ادمین پیش‌فرض: ${ADMIN_PHONE}`);
});
