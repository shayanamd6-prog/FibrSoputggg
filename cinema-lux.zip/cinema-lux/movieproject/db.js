const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'data', 'db.json');

function defaultData() {
  return {
    users: [],      // {id, name, phone, passwordHash, isAdmin}
    otps: {},        // phone -> {code, expiresAt}
    series: []        // {id, title, description, poster, genre, seasons:[{id,number,episodes:[{id,number,title,qualities:{q240,q480,q720,q1080}}]}]}
  };
}

function load() {
  if (!fs.existsSync(DB_FILE)) {
    save(defaultData());
  }
  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    return defaultData();
  }
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function nextId(arr) {
  return arr.length ? Math.max(...arr.map(x => x.id)) + 1 : 1;
}

module.exports = { load, save, nextId };
