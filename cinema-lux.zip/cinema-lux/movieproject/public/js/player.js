function initPlayer(qualities, defaultQuality) {
  const video = document.getElementById('mainVideo');
  const select = document.getElementById('qualitySelect');
  const fsBtn = document.getElementById('fsBtn');

  function setSource(url, keepTime) {
    const t = keepTime ? video.currentTime : 0;
    const wasPlaying = !video.paused;
    video.src = url;
    video.currentTime = t;
    if (wasPlaying) video.play();
  }

  if (select) {
    select.addEventListener('change', () => {
      const url = qualities[select.value];
      setSource(url, true);
    });
  }

  if (fsBtn) {
    fsBtn.addEventListener('click', () => {
      if (video.requestFullscreen) video.requestFullscreen();
      else if (video.webkitRequestFullscreen) video.webkitRequestFullscreen();
    });
  }

  // دوبار کلیک روی ویدیو هم تمام‌صفحه کند
  video.addEventListener('dblclick', () => {
    if (video.requestFullscreen) video.requestFullscreen();
    else if (video.webkitRequestFullscreen) video.webkitRequestFullscreen();
  });
}
